package com.ionhex975.vulkanpostfx.client.runtime;

import com.ionhex975.vulkanpostfx.VulkanPostFX;
import com.ionhex975.vulkanpostfx.client.diagnostics.VpfxFailureDiagnostics;
import com.ionhex975.vulkanpostfx.client.effect.PostFxEffectRegistry;
import com.ionhex975.vulkanpostfx.client.pack.ActiveShaderPackManager;
import com.ionhex975.vulkanpostfx.client.pack.ShaderPackContainer;
import com.ionhex975.vulkanpostfx.client.pack.ZipShaderPackReader;
import com.ionhex975.vulkanpostfx.client.pack.vpfx.VpfxNativePackDefinition;
import com.ionhex975.vulkanpostfx.client.runtime.nativevpfx.VpfxNativeFullscreenDryRun;
import com.ionhex975.vulkanpostfx.client.runtime.nativevpfx.VpfxNativeRuntimeSupport;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipPostEffectConfig;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipPostEffectParser;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipShaderReferenceValidationResult;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipShaderReferenceValidator;
import com.ionhex975.vulkanpostfx.client.runtime.texture.VpfxRuntimeTextureBootstrap;
import com.ionhex975.vulkanpostfx.client.runtime.texture.VpfxRuntimeTextureRegistry;
import com.ionhex975.vulkanpostfx.client.runtime.vpfx.VpfxPostChainBackend;
import com.ionhex975.vulkanpostfx.client.runtime.vpfx.VpfxRuntimeBackend;
import com.ionhex975.vulkanpostfx.client.runtime.zip.RuntimeZipPackMaterializationResult;
import com.ionhex975.vulkanpostfx.client.runtime.zip.RuntimeZipPackState;
import com.ionhex975.vulkanpostfx.client.state.PostFxRuntimeState;
import net.minecraft.client.Minecraft;

public final class ActivePostEffectBridge {
    private static ActivePostEffectSource activeSource = ActivePostEffectSource.NONE;

    private ActivePostEffectBridge() {
    }

    public static void refreshFromActivePack() {
        ShaderPackContainer activePack = ActiveShaderPackManager.getActivePack();
        if (activePack == null) {
            activeSource = ActivePostEffectSource.NONE;
            RuntimeZipPackState.clear();
            VpfxRuntimeTextureRegistry.clear();
            PostFxRuntimeState.clearActiveExternalPostEffectId();
            PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);
            PostFxRuntimeState.setActiveRuntimeBackend(new VpfxPostChainBackend());

            VulkanPostFX.LOGGER.warn(
                    "[{}] No active shader pack; active post effect source cleared",
                    VulkanPostFX.MOD_ID
            );
            return;
        }

        String entryPostEffect = activePack.manifest().entryPostEffect();
        if (entryPostEffect == null || entryPostEffect.isBlank()) {
            activeSource = ActivePostEffectSource.NONE;
            RuntimeZipPackState.clear();
            VpfxRuntimeTextureRegistry.clear();
            PostFxRuntimeState.clearActiveExternalPostEffectId();
            PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);
            PostFxRuntimeState.setActiveRuntimeBackend(new VpfxPostChainBackend());

            VulkanPostFX.LOGGER.warn(
                    "[{}] Active shader pack '{}' does not declare entry_post_effect",
                    VulkanPostFX.MOD_ID,
                    activePack.manifest().name()
            );
            return;
        }

        if ("builtin".equals(activePack.sourceId())) {
            activeSource = new ActivePostEffectSource(
                    "builtin",
                    entryPostEffect,
                    "",
                    null,
                    null
            );

            RuntimeZipPackState.clear();
            VpfxRuntimeTextureRegistry.clear();
            PostFxRuntimeState.clearActiveExternalPostEffectId();
            PostFxRuntimeState.setActiveEffectKey(ActiveShaderPackManager.getActiveEffectKey());
            PostFxRuntimeState.setActiveRuntimeBackend(new VpfxPostChainBackend());

            VulkanPostFX.LOGGER.info(
                    "[{}] Active post effect source prepared from builtin pack: {}, resolvedBuiltinEffectKey={}",
                    VulkanPostFX.MOD_ID,
                    entryPostEffect,
                    PostFxRuntimeState.getActiveEffectKey()
            );
            return;
        }

        if ("zip".equals(activePack.sourceId())) {
            try {
                String rawJson = ZipShaderPackReader.readText(activePack.sourcePath(), entryPostEffect);
                ZipPostEffectConfig parsedConfig = ZipPostEffectParser.parse(rawJson);
                ZipShaderReferenceValidationResult validationResult =
                        ZipShaderReferenceValidator.validate(activePack, parsedConfig);

                if (!validationResult.isValid()) {
                    activeSource = ActivePostEffectSource.NONE;
                    RuntimeZipPackState.clear();
                    VpfxRuntimeTextureRegistry.clear();
                    PostFxRuntimeState.clearActiveExternalPostEffectId();
                    PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);
                    PostFxRuntimeState.setActiveRuntimeBackend(new VpfxPostChainBackend());

                    VulkanPostFX.LOGGER.error(
                            "[{}] Active ZIP post effect source failed shader validation: checked={}, missing={}",
                            VulkanPostFX.MOD_ID,
                            validationResult.checkedCount(),
                            validationResult.missingReferences()
                    );
                    return;
                }

                VpfxRuntimeBackend backend = selectRuntimeBackend(activePack);
                PostFxRuntimeState.setActiveRuntimeBackend(backend);

                String nativePreparationFallbackReason = null;
                if (activePack.isVpfxNativePack()
                        && activePack.vpfxDefinition() != null
                        && backend.capabilities().nativeRuntime()) {
                    VpfxNativePackDefinition vpfxDef = activePack.vpfxDefinition();
                    try {
                        VpfxNativeRuntimeSupport.runDryRunCheck(vpfxDef.getManifest(), vpfxDef.getGraph());
                        VpfxNativeFullscreenDryRun.run(Minecraft.getInstance(), vpfxDef.getManifest(), vpfxDef.getGraph());
                    } catch (Throwable t) {
                        nativePreparationFallbackReason = "native backend preparation failed: "
                                + (t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName());
                        backend = new VpfxPostChainBackend();
                        PostFxRuntimeState.setActiveRuntimeBackend(backend);

                        VulkanPostFX.LOGGER.warn(
                                "[{}] VPFX native backend preparation failed. Falling back to minecraft_postchain without marking the pack failed: pack='{}', reason={}",
                                VulkanPostFX.MOD_ID,
                                activePack.manifest().name(),
                                nativePreparationFallbackReason,
                                t
                        );
                    }
                }

                RuntimeZipPackMaterializationResult materialized = backend.materialize(
                        activePack,
                        Minecraft.getInstance().gameDirectory.toPath()
                );

                RuntimeZipPackState.apply(materialized);

                // 注册 runtime texture manifest，供后续 pass/sampler 绑定使用
                VpfxRuntimeTextureRegistry.clear();
                VpfxRuntimeTextureBootstrap.registerRuntimeTextureManifest(
                        materialized.runtimeTextureManifestPath()
                );

                PostFxRuntimeState.setActiveExternalPostEffectId(materialized.externalPostEffectId());
                PostFxRuntimeState.setActiveEffectKey("external_zip");
                if (nativePreparationFallbackReason != null) {
                    PostFxRuntimeState.markNativeRuntimeFallback(
                            materialized.externalPostEffectId(),
                            nativePreparationFallbackReason
                    );
                }

                activeSource = new ActivePostEffectSource(
                        "zip",
                        activePack.sourcePath() + "!/" + entryPostEffect,
                        rawJson,
                        parsedConfig,
                        validationResult
                );

                VulkanPostFX.LOGGER.info(
                        "[{}] Active post effect source loaded from zip: {} ({} chars, {} targets, {} passes, checkedShaders={}, runtimeNamespace={}, externalPostEffectId={}, runtimeTextureManifest={}, backend={}, backendCaps={})",
                        VulkanPostFX.MOD_ID,
                        activeSource.displayPath(),
                        rawJson.length(),
                        parsedConfig.targets().size(),
                        parsedConfig.passes().size(),
                        validationResult.checkedCount(),
                        materialized.runtimeNamespace(),
                        materialized.externalPostEffectId(),
                        materialized.runtimeTextureManifestPath(),
                        backend.id(),
                        backend.capabilities()
                );
                return;
            } catch (Exception e) {
                activeSource = ActivePostEffectSource.NONE;
                RuntimeZipPackState.clear();
                VpfxRuntimeTextureRegistry.clear();
                PostFxRuntimeState.clearActiveExternalPostEffectId();
                PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);
                PostFxRuntimeState.setActiveRuntimeBackend(new VpfxPostChainBackend());
                VpfxFailureDiagnostics.write("materialize/activate", e, activePack.manifest().name());

                VulkanPostFX.LOGGER.error(
                        "[{}] Failed to load active ZIP post effect source from '{}'",
                        VulkanPostFX.MOD_ID,
                        entryPostEffect,
                        e
                );
                return;
            }
        }

        activeSource = ActivePostEffectSource.NONE;
        RuntimeZipPackState.clear();
        VpfxRuntimeTextureRegistry.clear();
        PostFxRuntimeState.clearActiveExternalPostEffectId();
        PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);
        PostFxRuntimeState.setActiveRuntimeBackend(new VpfxPostChainBackend());

        VulkanPostFX.LOGGER.warn(
                "[{}] Unsupported shader pack source '{}'; active post effect source cleared",
                VulkanPostFX.MOD_ID,
                activePack.sourceId()
        );
    }

    private static VpfxRuntimeBackend selectRuntimeBackend(ShaderPackContainer activePack) {
        if (activePack != null && activePack.isVpfxNativePack() && activePack.vpfxDefinition() != null) {
            VpfxNativePackDefinition vpfxDef = activePack.vpfxDefinition();
            return VpfxNativeRuntimeSupport.selectBackend(
                    vpfxDef.getManifest(),
                    vpfxDef.getGraph()
            );
        }

        return new VpfxPostChainBackend();
    }

    public static ActivePostEffectSource getActiveSource() {
        return activeSource;
    }
}