package com.ionhex975.vulkanpostfx.client.gui;

import com.ionhex975.vulkanpostfx.VulkanPostFX;
import com.ionhex975.vulkanpostfx.client.config.ActiveShaderPackConfig;
import com.ionhex975.vulkanpostfx.client.pack.ActiveShaderPackManager;
import com.ionhex975.vulkanpostfx.client.pack.ShaderPackContainer;
import com.ionhex975.vulkanpostfx.client.reload.VpfxHotReloadManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * VPFX 光影包选择菜单。
 *
 * 注意：
 * - 26.2 snapshot GUI 绘制入口使用 GuiGraphicsExtractor#extractRenderState
 * - 不使用 GuiGraphics/render，避免 compileClientJava 找不到 GuiGraphics
 * - 打开/关闭屏幕走 VpfxScreenBridge，避免 Minecraft#setScreen 映射名变化
 */
public final class VpfxShaderPackSelectionScreen extends Screen {
    private static final int PANEL_WIDTH = 340;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 4;
    private static final int EXTERNAL_PACKS_PER_PAGE = 7;

    private final Screen parent;
    private final List<Button> actionButtons = new ArrayList<>();

    private int page;
    private boolean reloadInProgress;
    private Component statusMessage;

    public VpfxShaderPackSelectionScreen(Screen parent) {
        this(parent, Component.translatable("screen.vulkanpostfx.shaderpacks.status.ready"));
    }

    private VpfxShaderPackSelectionScreen(Screen parent, Component statusMessage) {
        super(Component.translatable("screen.vulkanpostfx.shaderpacks.title"));
        this.parent = parent;
        this.statusMessage = statusMessage;
    }

    @Override
    protected void init() {
        actionButtons.clear();
        ActiveShaderPackManager.bootstrap();

        int x = (this.width - PANEL_WIDTH) / 2;
        int y = 46;

        addActionButton(Button.builder(
                Component.translatable("screen.vulkanpostfx.shaderpacks.reload_current"),
                button -> beginReload(
                        VpfxHotReloadManager.hotReloadCurrentPack(
                                Minecraft.getInstance(),
                                true,
                                "shader-pack-menu:reload-current"
                        ),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.status.reload_started"),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.status.reload_done")
                )
        ).bounds(x, y, PANEL_WIDTH, BUTTON_HEIGHT).build());
        y += BUTTON_HEIGHT + BUTTON_GAP + 6;

        addActionButton(Button.builder(
                withSelectedPrefix(
                        isAutoSelected(),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.auto")
                ),
                button -> beginReload(
                        VpfxHotReloadManager.selectAutoAndReload(
                                Minecraft.getInstance(),
                                "shader-pack-menu:select-auto"
                        ),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.status.auto_started"),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.status.auto_done")
                )
        ).bounds(x, y, PANEL_WIDTH, BUTTON_HEIGHT).build());
        y += BUTTON_HEIGHT + BUTTON_GAP;

        addActionButton(Button.builder(
                withSelectedPrefix(
                        isBuiltinSelected(),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.builtin")
                ),
                button -> beginReload(
                        VpfxHotReloadManager.selectBuiltinAndReload(
                                Minecraft.getInstance(),
                                "shader-pack-menu:select-builtin"
                        ),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.status.builtin_started"),
                        Component.translatable("screen.vulkanpostfx.shaderpacks.status.builtin_done")
                )
        ).bounds(x, y, PANEL_WIDTH, BUTTON_HEIGHT).build());
        y += BUTTON_HEIGHT + BUTTON_GAP + 6;

        List<ShaderPackContainer> externalPacks = ActiveShaderPackManager.getExternalPacks();
        int maxPage = maxPage(externalPacks.size());
        if (page > maxPage) {
            page = maxPage;
        }

        if (externalPacks.isEmpty()) {
            Button empty = Button.builder(
                    Component.translatable("screen.vulkanpostfx.shaderpacks.no_external"),
                    button -> {
                    }
            ).bounds(x, y, PANEL_WIDTH, BUTTON_HEIGHT).build();

            empty.active = false;
            addActionButton(empty);
            y += BUTTON_HEIGHT + BUTTON_GAP;
        } else {
            int start = page * EXTERNAL_PACKS_PER_PAGE;
            int end = Math.min(start + EXTERNAL_PACKS_PER_PAGE, externalPacks.size());

            for (int index = start; index < end; index++) {
                ShaderPackContainer pack = externalPacks.get(index);

                addActionButton(Button.builder(
                        withSelectedPrefix(
                                ActiveShaderPackManager.isActivePack(pack),
                                Component.literal(pack.manifest().name() + "  [" + pack.manifest().id() + "]")
                        ),
                        button -> beginReload(
                                VpfxHotReloadManager.selectExternalAndReload(
                                        Minecraft.getInstance(),
                                        pack.manifest().id(),
                                        "shader-pack-menu:select-external:" + pack.manifest().id()
                                ),
                                Component.literal("Loading VPFX pack: " + pack.manifest().name()),
                                Component.literal("Loaded VPFX pack: " + pack.manifest().name())
                        )
                ).bounds(x, y, PANEL_WIDTH, BUTTON_HEIGHT).build());

                y += BUTTON_HEIGHT + BUTTON_GAP;
            }
        }

        if (externalPacks.size() > EXTERNAL_PACKS_PER_PAGE) {
            int halfWidth = (PANEL_WIDTH - BUTTON_GAP) / 2;

            Button previous = Button.builder(
                    Component.translatable("screen.vulkanpostfx.shaderpacks.previous_page"),
                    button -> {
                        page = Math.max(0, page - 1);
                        rebuildWidgets();
                    }
            ).bounds(x, y, halfWidth, BUTTON_HEIGHT).build();

            previous.active = page > 0;
            addActionButton(previous);

            Button next = Button.builder(
                    Component.translatable("screen.vulkanpostfx.shaderpacks.next_page"),
                    button -> {
                        page = Math.min(maxPage, page + 1);
                        rebuildWidgets();
                    }
            ).bounds(x + halfWidth + BUTTON_GAP, y, halfWidth, BUTTON_HEIGHT).build();

            next.active = page < maxPage;
            addActionButton(next);

            y += BUTTON_HEIGHT + BUTTON_GAP;
        }

        y += 8;

        addActionButton(Button.builder(
                Component.translatable("gui.done"),
                button -> onClose()
        ).bounds(x, y, PANEL_WIDTH, BUTTON_HEIGHT).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int textX = (this.width - PANEL_WIDTH) / 2;
        int y = 14;

        drawCenteredText(graphics, textOf(this.title), centerX, y, 0xFFFFFFFF);
        y += 14;

        ShaderPackContainer activePack = ActiveShaderPackManager.getActivePack();
        String activeText = activePack == null
                ? textOf(Component.translatable("screen.vulkanpostfx.shaderpacks.active.none"))
                : "Active: " + activePack.manifest().name() + " [" + activePack.sourceId() + "]";

        drawCenteredText(graphics, activeText, centerX, y, 0xFFA0FFA0);
        y += 12;

        drawCenteredText(
                graphics,
                textOf(statusMessage),
                centerX,
                y,
                reloadInProgress ? 0xFFFFFF80 : 0xFFC8C8C8
        );

        int bottomY = this.height - 38;
        Path shaderPackDirectory = ActiveShaderPackManager.getShaderPackDirectory();

        graphics.text(
                this.font,
                "Folder: " + shaderPackDirectory,
                textX,
                bottomY,
                0xFF808080
        );

        graphics.text(
                this.font,
                textOf(Component.translatable("screen.vulkanpostfx.shaderpacks.hint")),
                textX,
                bottomY + 11,
                0xFF808080
        );
    }

    @Override
    public void onClose() {
        VpfxScreenBridge.setScreen(parent);
    }

    private void addActionButton(Button button) {
        actionButtons.add(button);
        addRenderableWidget(button);
    }

    private void beginReload(
            CompletableFuture<Void> reloadFuture,
            Component pendingMessage,
            Component successMessage
    ) {
        reloadInProgress = true;
        statusMessage = pendingMessage;
        setButtonsActive(false);

        reloadFuture.whenComplete((ignored, throwable) -> Minecraft.getInstance().execute(() -> {
            reloadInProgress = false;

            if (throwable != null) {
                String message = throwable.getMessage();
                statusMessage = Component.literal("VPFX reload failed" + (message == null ? "" : ": " + message));

                VulkanPostFX.LOGGER.error(
                        "[{}] VPFX shader pack menu reload action failed",
                        VulkanPostFX.MOD_ID,
                        throwable
                );
            } else {
                statusMessage = successMessage;
            }

            if (VpfxScreenBridge.isCurrentScreen(this)) {
                rebuildWidgets();
            }
        }));
    }

    private void setButtonsActive(boolean active) {
        for (Button button : actionButtons) {
            button.active = active;
        }
    }

    private boolean isAutoSelected() {
        ActiveShaderPackConfig config = ActiveShaderPackManager.getActiveConfig();
        return config.autoSelectExternalPack()
                && !config.hasExplicitExternalPackId()
                && !config.forcesBuiltinPack();
    }

    private boolean isBuiltinSelected() {
        return ActiveShaderPackManager.getActiveConfig().forcesBuiltinPack();
    }

    private Component withSelectedPrefix(boolean selected, Component label) {
        return Component.literal(selected ? "✓ " : "  ").append(label);
    }

    private int maxPage(int externalPackCount) {
        if (externalPackCount <= 0) {
            return 0;
        }

        return (externalPackCount - 1) / EXTERNAL_PACKS_PER_PAGE;
    }

    private void drawCenteredText(GuiGraphicsExtractor graphics, String text, int centerX, int y, int color) {
        graphics.text(this.font, text, centerX - this.font.width(text) / 2, y, color);
    }

    private static String textOf(Component component) {
        return component == null ? "" : component.getString();
    }
}