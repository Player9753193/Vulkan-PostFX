package com.ionhex975.vulkanpostfx.client.runtime;

import com.ionhex975.vulkanpostfx.VulkanPostFX;
import com.ionhex975.vulkanpostfx.client.diagnostics.VpfxFailureDiagnostics;
import com.ionhex975.vulkanpostfx.client.effect.PostFxEffectRegistry;
import com.ionhex975.vulkanpostfx.client.diagnostics.VpfxDiagnosticsConfig;
import com.ionhex975.vulkanpostfx.client.pack.ActiveShaderPackManager;
import com.ionhex975.vulkanpostfx.client.pack.ShaderPackContainer;
import com.ionhex975.vulkanpostfx.client.pack.ZipShaderPackReader;
import com.ionhex975.vulkanpostfx.client.pack.vpfx.VpfxNativePackDefinition;
import com.ionhex975.vulkanpostfx.client.runtime.nativevpfx.VpfxNativeFullscreenDryRun;
import com.ionhex975.vulkanpostfx.client.runtime.nativevpfx.VpfxNativeRuntimeSupport;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipPostEffectConfig;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipPostEffectParser;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipShaderReferenceValidationResult;
import com.ionhex975.vulkanpostfx.client.runtime.posteffect.ZipShaderReferenceValidator;
import com.ionhex975.vulkanpostfx.client.runtime.texture.VpfxRuntimeTextureBootstrap;
import com.ionhex975.vulkanpostfx.client.runtime.texture.VpfxRuntimeTextureRegistry;
import com.ionhex975.vulkanpostfx.client.runtime.vpfx.VpfxPostChainBackend;
import com.ionhex975.vulkanpostfx.client.runtime.vpfx.VpfxRuntimeBackend;
import com.ionhex975.vulkanpostfx.client.runtime.zip.RuntimeZipPackMaterializationResult;
import com.ionhex975.vulkanpostfx.client.runtime.zip.RuntimeZipPackState;
import com.ionhex975.vulkanpostfx.client.state.PostFxRuntimeState;
import net.minecraft.client.Minecraft;

public final class ActivePostEffectBridge {
    private static ActivePostEffectSource activeSource = ActivePostEffectSource.NONE;

    private ActivePostEffectBridge() {
    }

    public static void refreshFromActivePack() {
        ShaderPackContainer activePack = ActiveShaderPackManager.getActivePack();
        if (activePack == null) {
            clearActiveSource("No active shader pack; active post effect source cleared");
            return;
        }

        String entryPostEffect = activePack.manifest().entryPostEffect();
        if (entryPostEffect == null || entryPostEffect.isBlank()) {
            clearActiveSource("Active shader pack '" + activePack.manifest().name() + "' does not declare entry_post_effect");
            return;
        }

        if ("builtin".equals(activePack.sourceId())) {
            activeSource = new ActivePostEffectSource(
                    "builtin",
                    entryPostEffect,
                    "",
                    null,
                    null
            );

            RuntimeZipPackState.clear();
            VpfxRuntimeTextureRegistry.clear();
            PostFxRuntimeState.clearActiveExternalPostEffectId();
            PostFxRuntimeState.setActiveEffectKey(ActiveShaderPackManager.getActiveEffectKey());
            PostFxRuntimeState.resetActiveRuntimeBackend();

            VulkanPostFX.LOGGER.info(
                    "[{}] Active post effect source prepared from builtin pack: {}, resolvedBuiltinEffectKey={}",
                    VulkanPostFX.MOD_ID,
                    entryPostEffect,
                    PostFxRuntimeState.getActiveEffectKey()
            );
            return;
        }

        if ("zip".equals(activePack.sourceId())) {
            try {
                String rawJson = ZipShaderPackReader.readText(activePack.sourcePath(), entryPostEffect);
                ZipPostEffectConfig parsedConfig = ZipPostEffectParser.parse(rawJson);
                ZipShaderReferenceValidationResult validationResult =
                        ZipShaderReferenceValidator.validate(activePack, parsedConfig);

                if (!validationResult.isValid()) {
                    clearActiveSource("Active ZIP post effect source failed shader validation: checked="
                            + validationResult.checkedCount()
                            + ", missing="
                            + validationResult.missingReferences());
                    return;
                }

                VpfxRuntimeBackend backend = chooseRuntimeBackend(activePack);
                PostFxRuntimeState.setActiveRuntimeBackend(
                        backend.id(),
                        backend.displayName(),
                        backend.capabilities().usesPostChain(),
                        backend.capabilities().nativeRuntime()
                );

                if (activePack.isVpfxNativePack()) {
                    VpfxNativePackDefinition vpfxDef = activePack.vpfxDefinition();
                    VpfxNativeRuntimeSupport.runDryRunCheck(vpfxDef.getManifest(), vpfxDef.getGraph());
                    if (VpfxDiagnosticsConfig.legacyNativeDiagnosticsEnabled()) {
                        VpfxNativeFullscreenDryRun.run(Minecraft.getInstance(), vpfxDef.getManifest(), vpfxDef.getGraph());
                    }
                }

                RuntimeZipPackMaterializationResult materialized = backend.materialize(
                        activePack,
                        Minecraft.getInstance().gameDirectory.toPath()
                );

                RuntimeZipPackState.apply(materialized);

                // 注册 runtime texture manifest，供后续 pass/sampler 绑定使用。
                VpfxRuntimeTextureRegistry.clear();
                VpfxRuntimeTextureBootstrap.registerRuntimeTextureManifest(
                        materialized.runtimeTextureManifestPath()
                );

                PostFxRuntimeState.setActiveExternalPostEffectId(materialized.externalPostEffectId());
                PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);

                activeSource = new ActivePostEffectSource(
                        "zip",
                        activePack.sourcePath() + "!/" + entryPostEffect,
                        rawJson,
                        parsedConfig,
                        validationResult
                );

                VulkanPostFX.LOGGER.info(
                        "[{}] Active post effect source loaded from zip: {} ({} chars, {} targets, {} passes, checkedShaders={}, runtimeNamespace={}, externalPostEffectId={}, runtimeTextureManifest={}, backend={}, backendDisplay='{}', backendCaps={}, nativeDirect={}, postChainRuntime={})",
                        VulkanPostFX.MOD_ID,
                        activeSource.displayPath(),
                        rawJson.length(),
                        parsedConfig.targets().size(),
                        parsedConfig.passes().size(),
                        validationResult.checkedCount(),
                        materialized.runtimeNamespace(),
                        materialized.externalPostEffectId(),
                        materialized.runtimeTextureManifestPath(),
                        backend.id(),
                        backend.displayName(),
                        backend.capabilities(),
                        backend.capabilities().nativeRuntime(),
                        backend.capabilities().usesPostChain()
                );
                return;
            } catch (Exception e) {
                activeSource = ActivePostEffectSource.NONE;
                RuntimeZipPackState.clear();
                VpfxRuntimeTextureRegistry.clear();
                PostFxRuntimeState.clearActiveExternalPostEffectId();
                PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);
                PostFxRuntimeState.resetActiveRuntimeBackend();
                VpfxFailureDiagnostics.write("materialize/activate", e, activePack.manifest().name());

                VulkanPostFX.LOGGER.error(
                        "[{}] Failed to load active ZIP post effect source from '{}'",
                        VulkanPostFX.MOD_ID,
                        entryPostEffect,
                        e
                );
                return;
            }
        }

        clearActiveSource("Unsupported shader pack source '" + activePack.sourceId() + "'; active post effect source cleared");
    }

    private static VpfxRuntimeBackend chooseRuntimeBackend(ShaderPackContainer activePack) {
        if (activePack.isVpfxNativePack() && activePack.vpfxDefinition() != null) {
            VpfxNativePackDefinition vpfxDef = activePack.vpfxDefinition();
            return VpfxNativeRuntimeSupport.selectBackend(vpfxDef.getManifest(), vpfxDef.getGraph());
        }

        return new VpfxPostChainBackend();
    }

    private static void clearActiveSource(String message) {
        activeSource = ActivePostEffectSource.NONE;
        RuntimeZipPackState.clear();
        VpfxRuntimeTextureRegistry.clear();
        PostFxRuntimeState.clearActiveExternalPostEffectId();
        PostFxRuntimeState.setActiveEffectKey(PostFxEffectRegistry.DEBUG_INVERT);
        PostFxRuntimeState.resetActiveRuntimeBackend();

        VulkanPostFX.LOGGER.warn(
                "[{}] {}",
                VulkanPostFX.MOD_ID,
                message
        );
    }

    public static ActivePostEffectSource getActiveSource() {
        return activeSource;
    }
}