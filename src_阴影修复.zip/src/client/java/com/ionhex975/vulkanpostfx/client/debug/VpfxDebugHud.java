package com.ionhex975.vulkanpostfx.client.debug;

import com.ionhex975.vulkanpostfx.client.shadow.ShadowFrameState;
import com.ionhex975.vulkanpostfx.client.shadow.ShadowRenderTargetsLite;
import com.ionhex975.vulkanpostfx.client.state.PostFxRuntimeState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

public final class VpfxDebugHud {
	private static final int BASE_X = 4;
	private static final int LINE_HEIGHT = 10;
	private static final int COLOR_HEADER = 0xFF66CCFF;
	private static final int COLOR_ON = 0xFF55FF55;
	private static final int COLOR_OFF = 0xFFFF5555;
	private static final int COLOR_INFO = 0xFFCCCCCC;
	private static final int COLOR_LABEL = 0xFFAAAAAA;

	private VpfxDebugHud() {
	}

	public static void render(GuiGraphicsExtractor graphics) {
		if (!PostFxRuntimeState.isDebugEffectEnabled()
				&& !PostFxRuntimeState.isShadowDepthDebugViewEnabled()) {
			return;
		}

		Minecraft client = Minecraft.getInstance();
		if (client.player == null) {
			return;
		}

		int y = 4;
		int color;

		color = PostFxRuntimeState.isDebugEffectEnabled() ? COLOR_ON : COLOR_OFF;
		graphics.text(client.font, "[VPFX] " + (PostFxRuntimeState.isDebugEffectEnabled() ? "ON" : "OFF"), BASE_X, y, color);
		y += LINE_HEIGHT;

		graphics.text(client.font, "Backend: " + PostFxRuntimeState.getBackendName(), BASE_X, y, COLOR_INFO);
		y += LINE_HEIGHT;

		Identifier externalId = PostFxRuntimeState.getActiveExternalPostEffectId();
		String effectInfo;
		if (PostFxRuntimeState.isShadowDepthDebugViewEnabled()) {
			effectInfo = "Effect: SHADOW DEPTH DEBUG";
		} else if (externalId != null) {
			effectInfo = "Effect: " + externalId;
		} else {
			effectInfo = "Effect: " + PostFxRuntimeState.getActiveEffectKey();
		}
		graphics.text(client.font, effectInfo, BASE_X, y, COLOR_INFO);
		y += LINE_HEIGHT;

		ShadowFrameState shadowState = ShadowFrameState.get();
		ShadowRenderTargetsLite shadowTargets = ShadowRenderTargetsLite.get();

		color = shadowState.isShadowPassEnabled() ? COLOR_ON : COLOR_OFF;
		String shadowStatus = shadowState.isShadowPassEnabled()
				? "Shadow: ON (pass=" + shadowState.wasShadowPassExecuted()
						+ " casters=" + shadowState.wereShadowCastersRendered()
						+ ")"
				: "Shadow: OFF";
		graphics.text(client.font, shadowStatus, BASE_X, y, color);
		y += LINE_HEIGHT;

		if (shadowState.isShadowPassEnabled() && shadowState.isShadowTargetReady()) {
			graphics.text(client.font, "  size=" + shadowState.getShadowMapSize()
							+ " terrainDist=" + formatDist(shadowState.getTerrainShadowDistance())
							+ " entityDist=" + formatDist(shadowState.getEntityShadowDistance()),
					BASE_X, y, COLOR_LABEL);
			y += LINE_HEIGHT;

			String targetInfo = "  targetReady=" + shadowTargets.isReady()
					+ " executed=" + shadowState.wasShadowPassExecuted()
					+ " casters=" + shadowState.wereShadowCastersRendered();
			graphics.text(client.font, targetInfo, BASE_X, y, COLOR_LABEL);
			y += LINE_HEIGHT;
		}
	}

	private static String formatDist(float value) {
		return String.format("%.0f", value);
	}
}
