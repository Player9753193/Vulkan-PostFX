#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

layout(std140) uniform VpfxTerrainShadow {
    vec4 ShadowInfo;
    vec4 ShadowLightInfo;
    mat4 ShadowViewProjMat;
};

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec4 shadowClipPos;
in float shadowSkyLight;
in float shadowBlockLight;

out vec4 fragColor;

vec4 sampleNearest(sampler2D source, vec2 uv, vec2 pixelSize, vec2 du, vec2 dv, vec2 texelScreenSize) {
    vec2 uvTexelCoords = uv / pixelSize;
    vec2 texelCenter = round(uvTexelCoords) - 0.5f;
    vec2 texelOffset = uvTexelCoords - texelCenter;
    texelOffset = (texelOffset - 0.5f) * pixelSize / texelScreenSize + 0.5f;
    texelOffset = clamp(texelOffset, 0.0f, 1.0f);
    uv = (texelCenter + texelOffset) * pixelSize;
    return textureGrad(source, uv, du, dv);
}

vec4 sampleNearest(sampler2D source, vec2 uv, vec2 pixelSize) {
    vec2 du = dFdx(uv);
    vec2 dv = dFdy(uv);
    vec2 texelScreenSize = sqrt(du * du + dv * dv);
    return sampleNearest(source, uv, pixelSize, du, dv, texelScreenSize);
}

vec4 sampleRGSS(sampler2D source, vec2 uv, vec2 pixelSize) {
    vec2 du = dFdx(uv);
    vec2 dv = dFdy(uv);
    vec2 texelScreenSize = sqrt(du * du + dv * dv);
    float maxTexelSize = max(texelScreenSize.x, texelScreenSize.y);
    float minPixelSize = min(pixelSize.x, pixelSize.y);
    float transitionStart = minPixelSize * 1.0;
    float transitionEnd = minPixelSize * 2.0;
    float blendFactor = smoothstep(transitionStart, transitionEnd, maxTexelSize);
    float duLength = length(du);
    float dvLength = length(dv);
    float minDerivative = min(duLength, dvLength);
    float maxDerivative = max(duLength, dvLength);
    float effectiveDerivative = sqrt(minDerivative * maxDerivative);
    float mipLevelExact = max(0.0, log2(effectiveDerivative / minPixelSize));
    float mipLevelLow = floor(mipLevelExact);
    float mipLevelHigh = mipLevelLow + 1.0;
    float mipBlend = fract(mipLevelExact);

    const vec2 offsets[4] = vec2[](
        vec2(0.125, 0.375),
        vec2(-0.125, -0.375),
        vec2(0.375, -0.125),
        vec2(-0.375, 0.125)
    );

    vec4 rgssColorLow = vec4(0.0);
    vec4 rgssColorHigh = vec4(0.0);
    for (int i = 0; i < 4; ++i) {
        vec2 sampleUV = uv + offsets[i] * pixelSize;
        rgssColorLow += textureLod(source, sampleUV, mipLevelLow);
        rgssColorHigh += textureLod(source, sampleUV, mipLevelHigh);
    }

    rgssColorLow *= 0.25;
    rgssColorHigh *= 0.25;

    vec4 rgssColor = mix(rgssColorLow, rgssColorHigh, mipBlend);
    vec4 nearestColor = sampleNearest(source, uv, pixelSize, du, dv, texelScreenSize);
    return mix(nearestColor, rgssColor, blendFactor);
}

float safeDenominator(float value) {
    if (abs(value) > 1e-6) {
        return value;
    }
    return value < 0.0 ? -1e-6 : 1e-6;
}

vec3 safeNormalize(vec3 value, vec3 fallback) {
    float lenSq = dot(value, value);
    if (lenSq > 1e-8) {
        return value * inversesqrt(lenSq);
    }
    return fallback;
}

float shadowEdgeFade(vec2 shadowUv) {
    vec2 edge = min(shadowUv, 1.0 - shadowUv);
    return smoothstep(0.0, 0.04, min(edge.x, edge.y));
}

/*
 * View-independent shadow receiver path.
 *
 * The terrain shader does not receive a stable block-face normal attribute.
 * The previous receiver logic reconstructed a normal from screen-space
 * derivatives of camera-relative terrain position:
 *
 * That made the shadow/light mask depend on the player's current view
 * projection.  In practice the receiver mask could appear to rotate while the
 * player looked around.
 *
 * This pass removes all non-essential player-view receiver calculations from
 * shadowing.  Ordinary block texture filtering still uses dFdx/dFdy above; that
 * only affects texture sampling and does not choose the shadow direction.
 */
vec3 resolveLightDirection() {
    return safeNormalize(ShadowLightInfo.xyz, vec3(0.0, -1.0, 0.0));
}

float resolveReceiverBias() {
    vec3 lightDirection = resolveLightDirection();
    float baseBias = max(ShadowInfo.x, 0.0002);

    /*
     * Keep shadow bias independent from receiver normals and screen-space depth
     * derivatives.  Low-angle light gets a little extra bias to reduce acne, but
     * no player-view variable participates in the calculation.
     */
    float lowLight = 1.0 - smoothstep(0.08, 0.26, abs(lightDirection.y));
    return clamp(baseBias + lowLight * 0.0018, baseBias, 0.0038);
}

float resolveSolarMaskStability() {
    vec3 lightDirection = resolveLightDirection();
    float lightHeight = abs(lightDirection.y);

    /*
     * World/light-space only: fade very-low-angle shadows, but do not inspect
     * the camera/view-dependent receiver plane.
     */
    return smoothstep(0.055, 0.20, lightHeight);
}

float sampleSolarRayMask() {
    if (ShadowInfo.w < 0.5) {
        return 0.0;
    }

    if (shadowSkyLight < 0.20) {
        return 0.0;
    }

    vec3 shadowNdc = shadowClipPos.xyz / safeDenominator(shadowClipPos.w);
    if (shadowNdc.z < 0.0 || shadowNdc.z > 1.0) {
        return 0.0;
    }

    vec2 shadowUv = shadowNdc.xy * 0.5 + 0.5;
    if (shadowUv.x < 0.0 || shadowUv.x > 1.0 || shadowUv.y < 0.0 || shadowUv.y > 1.0) {
        return 0.0;
    }

    vec2 texel = vec2(1.0 / max(ShadowInfo.y, 1.0));
    if (shadowUv.x < texel.x || shadowUv.x > 1.0 - texel.x || shadowUv.y < texel.y || shadowUv.y > 1.0 - texel.y) {
        return 0.0;
    }

    float bias = resolveReceiverBias();
    float mask = 0.0;
    float weightSum = 0.0;

    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            vec2 offset = vec2(float(x), float(y));
            float sampleWeight = x == 0 && y == 0 ? 1.60 : (abs(x) + abs(y) == 1 ? 1.0 : 0.72);
            float storedDepth = texture(Sampler1, shadowUv + offset * texel).r;
            float rayDepth = storedDepth - shadowNdc.z - bias;
            float blocked = smoothstep(0.0, 0.0009, rayDepth);
            float depthShade = smoothstep(0.0004, 0.012, rayDepth);
            mask += blocked * mix(0.42, 1.0, depthShade) * sampleWeight;
            weightSum += sampleWeight;
        }
    }

    float skyReach = smoothstep(0.20, 0.86, shadowSkyLight);
    return clamp(mask / max(weightSum, 1e-4) * shadowEdgeFade(shadowUv) * skyReach * resolveSolarMaskStability(), 0.0, 1.0);
}

float resolveLocalLightCoverage() {
    float blockLight = clamp(shadowBlockLight, 0.0, 1.0);
    float spread = smoothstep(0.04, 0.82, blockLight);
    float sourceCore = smoothstep(0.58, 1.0, blockLight);
    return clamp(max(spread * 0.76, sourceCore), 0.0, 1.0);
}

float resolveIrisStyleAmbientFloor(float localLightCoverage) {
    float skyAmbient = mix(0.34, 0.68, clamp(shadowSkyLight, 0.0, 1.0));
    float blockAmbient = localLightCoverage * 0.90;
    return clamp(max(max(ShadowInfo.z, skyAmbient), blockAmbient), 0.0, 0.88);
}

void main() {
    vec4 color = (UseRgss == 1 ? sampleRGSS(Sampler0, texCoord0, 1.0f / TextureSize) : sampleNearest(Sampler0, texCoord0, 1.0f / TextureSize)) * vertexColor;
    color = mix(FogColor * vec4(1, 1, 1, color.a), color, ChunkVisibility);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    float solarMask = sampleSolarRayMask();
    float localLightCoverage = resolveLocalLightCoverage();
    float maskedAmount = solarMask * (1.0 - localLightCoverage * 0.92);
    float ambientFloor = resolveIrisStyleAmbientFloor(localLightCoverage);
    float blackAmount = clamp(maskedAmount * mix(0.30, 0.58, clamp(ShadowInfo.z, 0.0, 1.0)), 0.0, 0.82);
    vec3 unmaskedColor = color.rgb;
    color.rgb = max(mix(color.rgb, vec3(0.0), blackAmount), unmaskedColor * ambientFloor);
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
